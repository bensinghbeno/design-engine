package com.example.tabstutorial;

public interface TabsListener {
    void onTabAdded();
    void onTabRemoved();
}
