funcodetuts
===========

Funcode sample tutorials

You can find the explanation for this code here: [Localized TextView on Android](http://www.myandroidsolutions.com/2015/01/15/load-localized-strings-at-runtime/). 
