package ro.kazy.tcpclient;

/**
 * Description
 *
 * @author Catalin Prata
 *         Date: 2/12/13
 */
public class Constants {

    public static final String CLOSED_CONNECTION = "kazy_closed_connection";
    public static final String LOGIN_NAME = "kazy_login_name";

}
