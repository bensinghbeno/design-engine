# Simple Android to PC TCP messaging example


This is a simple **Android** to **PC**(Java) messaging example, it uses AsyncTask to run the client tasks in a secondary thread.

You can find more details about the implementation on [myandroidsolutions](http://www.myandroidsolutions.com/2013/03/31/android-tcp-connection-enhanced/).
