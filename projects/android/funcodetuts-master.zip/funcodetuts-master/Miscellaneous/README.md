funcodetuts
===========

[![Join the chat at https://gitter.im/CatalinPrata/funcodetuts](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/CatalinPrata/funcodetuts?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Funcode sample tutorials
------------------------

[- Expandable list view](https://github.com/CatalinPrata/funcodetuts/tree/master/Miscellaneous/Miscellaneous/app/src/main/java/ro/funcode/miscellaneous/expandable_list_view)
